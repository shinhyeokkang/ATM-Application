package com.kftc.openbankingsample2.common.license;

import com.kftc.openbankingsample2.biz.center_auth.AbstractCenterAuthMainFragment;

public class OpenLicense extends AbstractCenterAuthMainFragment {
    // gradle 파일에 라이선스 표시됨
}
