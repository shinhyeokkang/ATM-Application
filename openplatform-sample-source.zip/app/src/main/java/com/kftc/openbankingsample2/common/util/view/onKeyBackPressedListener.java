package com.kftc.openbankingsample2.common.util.view;

public interface onKeyBackPressedListener {
    void onBackPressed();
}